package com.maplogik.pagelocators;

import org.openqa.selenium.By;

public class AdminHomePageLocator {

	public static By coCurricularAchiv = By.xpath("//*[text()='Co Curricular Achievements']");
	public static By certificationPageAdmin = By.xpath("//*[text()='Certifications']");
}
